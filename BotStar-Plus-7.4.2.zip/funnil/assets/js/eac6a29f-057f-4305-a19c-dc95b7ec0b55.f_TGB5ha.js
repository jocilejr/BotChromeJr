import{r}from"./c2056e40-0125-44d2-bec1-0c5c8c5f22b7.0Z0pQ5H2.js";var a=r();export{a as r};
